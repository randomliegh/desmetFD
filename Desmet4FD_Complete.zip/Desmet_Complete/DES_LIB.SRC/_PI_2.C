double _pi_2(void) { return 1.57079632679489661923; }

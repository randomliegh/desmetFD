/*	RERRNO.C	--	default routine to report on float errors.	*/

#include <errno.h>

static onum();
rerrno() {

	puts("errno=");
	onum(errno);
	switch (errno) {
		case EFLOAT:	puts("  *Error in Floating Point*");
						break;
		case EOVERFLOW:	puts("  *Overflow*");
						return;
		case EDIV0:		puts("  *Divide by Zero*");
						break;
		case EDOM:		puts("  *Domain Error*");
						break;
		case ERANGE:	puts("  *Out of Range*");
						break;
		}
	putchar('\n');
	exit(2);
	}

static onum(num)
	int num; {
	if (num > 9) {
		onum(num/10);
		num=num%10;
		}
	putchar(num+'0');
	}

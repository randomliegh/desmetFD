/*
 *	exp10(x)	10 to  the x power
 *
 *				Abramowitz & Stegun 4.2.4
 *				10**x = exp( x * log(10) )
 */

double exp();

double exp10(x)
double x;
	{
	return( exp( x * 2.302585092994 ) );
	}

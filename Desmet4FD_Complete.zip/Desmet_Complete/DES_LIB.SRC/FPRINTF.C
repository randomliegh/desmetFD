/*
	fprintf:
	Like printf, except that the first argument is
	a pointer to a stream, and the text
	is written to the file described by the buffer:
	ERROR (-1) returned on error.

	usage:
		fprintf(iobuf, format, arg1, arg2, ...);
*/

int fprintf(int * file, char * format) {
	int fputc();

	return _doprint(fputc, file, &format);
	}

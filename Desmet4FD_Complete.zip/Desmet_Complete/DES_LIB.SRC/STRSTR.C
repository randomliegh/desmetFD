char *strstr(char * s1, char * s2) {
	char * w, c = *s2, *strchr();

	while(w = strchr(s1, c)) {
		char *t1 = w, *t2 = s2;

		while(*t2 && *t1++ == *t2++) ;
		if(*t2 == 0)
			return w;
		s1 = w + 1;
		}
	return (char *)0;
	}

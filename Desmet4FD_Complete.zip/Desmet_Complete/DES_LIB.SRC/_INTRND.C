extern double fabs();

_intrnd(x)
double x;
	{
	int i;
	i = fabs(x) + 0.5;
	return x < 0.0 ? -i : i;
	}

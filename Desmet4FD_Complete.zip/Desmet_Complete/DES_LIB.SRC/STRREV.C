/*	STRREV  --	reverse a string.	*/

char *strrev(str)
	char *str; {
	int first,last;
	char ch;

	first=0;
	last=strlen(str)-1;
	while (first < last) {
		ch=str[last];
		str[last--]=str[first];
		str[first++]=ch;
		}
	return str;
	}

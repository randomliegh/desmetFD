#include <math.h>
#include <float.h>
#include <errno.h>

double atan2(double y, double x) {
	int neg_y = 0;
	double arctan;

	if (!(y || x)) {
		errno = EDOM;
		return y;
		}
	if (y < 0) {
		y = -y;
		neg_y++;
		}
	if (y - fabs(x) == y) 
		return (neg_y ? -_pi_2() : _pi_2());
	arctan = x >= DBL_MIN ? atan(y/x) : atan(DBL_MAX);
	if (x > 0) return (arctan);
	if (neg_y) return arctan - _pi();
	return arctan + _pi();
	}

/*	STRDUP  --	use malloc to make a copy of a string.	*/

char *malloc();

char *strdup(str)
	char *str; {
	char *strat;

	strat=malloc(strlen(str)+1);
	if (strat) strcpy(strat,str);
	return strat;
	}

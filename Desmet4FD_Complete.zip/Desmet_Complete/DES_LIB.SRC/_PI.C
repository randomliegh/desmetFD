double _pi(void) { return 3.14159265358979323846; }

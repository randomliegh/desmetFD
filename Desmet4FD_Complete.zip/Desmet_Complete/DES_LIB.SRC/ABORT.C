#include <stdio.h>

abort(){
	fputs("Abnormal program termination", stderr);
	_exit(3);
	}

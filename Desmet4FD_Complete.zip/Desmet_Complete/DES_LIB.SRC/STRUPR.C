/*	STRUPR  --  make a string upper case	*/

char *strupr(str)
	char *str; {
	char *strwas;

	strwas=str;
	while (*str) {
		if (*str >= 'a' && *str <= 'z') *str-='a'-'A';
		str++;
		}
	return strwas;
	}

/*
 * modf returns the positive fractional part of "value" and
 * stores the integer part indirectly through "iptr"
 */

double modf(value,iptr)
double value, *iptr;
	{
	int exp, *ip;

	ip = &value;
	exp = ((ip[3] >> 4) & 0x7FF) - 0x3FF;
	if(exp < 0)
		*iptr=0.0;
	else
		{
		*iptr = value;
		if(exp < 52)
			{
			exp = 52 - exp;
			for(ip = iptr; exp > 0; exp -= 16)
				{
				if(exp >= 16)
					*ip++ = 0;
				else
					*ip++ &= (-1) << exp;
				}
			}
		}
	return value - *iptr;
	}

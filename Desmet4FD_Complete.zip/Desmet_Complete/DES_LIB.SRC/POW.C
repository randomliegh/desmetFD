/*
 *	pow	returns "x" to the "y" power
 */

#include <errno.h>

extern double log(), exp();
static double zero = 0.0;

double pow(x, y)
double x, y;
	{
	long l;
	double temp;

	if(x <= zero)
		{
		if(x == zero)
			{
			if(y <= zero)
				errno = EDOM;
			return zero;
			}
		l = y;
		if(l != y)
			{
			errno = EDOM;
			return zero;
			}
		temp = exp(y * log(-x));
		if(l & 1)
			temp = -temp;
		}
	else
		temp = exp(y * log(x));
	return temp;
	}

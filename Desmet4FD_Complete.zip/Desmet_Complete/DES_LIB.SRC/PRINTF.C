/*
	printf fprintf to stdout
	ERROR (-1) returned on error.

	usage:
		printf(format, arg1, arg2, ...);
*/

int printf(char * format) {
	int fputc();

	return _doprint(fputc, (int *) 1, &format);
	}

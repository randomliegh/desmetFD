/*	STRTOK  --	return tokens from a string.
			    example:   char *tptr,*strtok();
	               tptr=strtok("   , aaa , bbb"," ,\t"); */

static char *nxt;

char *strpbrk();

#define	NULL (char *)0

char *strtok(char *str, char *toks) {
	char *beg, *end;

	if ((beg = (str == NULL) ? nxt : str) == NULL)
		return NULL;
	beg += strspn(beg,toks);
	if (*beg == '\0')
		return NULL;
	if((end = strpbrk(beg,toks)) == NULL)
		nxt = NULL;
	else {
		*end++ = '\0';
		nxt = end;
		}
	return beg;
	}

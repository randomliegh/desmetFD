/*	STRLWR  --  make a string lower case	*/

char *strlwr(str)
	char *str; {
	char *strwas;

	strwas=str;
	while (*str) {
		if (*str >= 'A' && *str <= 'Z') *str+='a'-'A';
		str++;
		}
	return strwas;
	}

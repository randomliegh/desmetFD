/*
**	int system(char cmd[]);
**
**	invoke command.com
*/

int system(char cmd[]) {
	char path[65], arg[129];

	if(getenv("COMSPEC", path, sizeof(path))) {
		arg[0] = '/';
		arg[1] = 'c';
		strcpy(&arg[2], cmd);
		if(!exec(path, arg)) return 0;
		}
	return -1;
	}

/*
 *	log10 returns the base 10 logarithm.
 */

extern double log();

static double c3 = 	0x3FDBCB7B1526E50E; /* 0.43429448190325182765 */

double log10(x)
double x;
	{
	return log(x) * c3;
	}

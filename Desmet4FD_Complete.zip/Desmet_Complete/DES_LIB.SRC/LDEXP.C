#include <float.h>
#include <errno.h>
/* Largest signed long int power of 2 */
#define MAXSHIFT	30

extern double frexp();

double
ldexp(value, exp)
register double value;
register int exp;
{
	int old_exp;

	if (exp == 0 || value == 0.0) /* nothing to do for zero */
		return (value);
	frexp(value, &old_exp);
	if (exp > 0) {
		if (exp + old_exp > DBL_MAX_EXP) { /* overflow */
			errno = ERANGE;
			return (value < 0 ? -DBL_MAX : DBL_MAX);
		}
		for ( ; exp > MAXSHIFT; exp -= MAXSHIFT)
			value *= (1L << MAXSHIFT);
		return (value * (1L << exp));
	}
	if (exp + old_exp < DBL_MIN_EXP) { /* underflow */
		errno = ERANGE;
		return (0.0);
	}
	for ( ; exp < -MAXSHIFT; exp += MAXSHIFT)
		value *= 1.0/(1L << MAXSHIFT); /* mult faster than div */
	return (value / (1L << -exp));
}

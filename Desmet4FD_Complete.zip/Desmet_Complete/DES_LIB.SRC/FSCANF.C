/*	FSCANF.C  -- FORMATTED FILE INPUT	*/

#define MAXLINE 135	/* Longest line of input expected from the console */

/*
	fscanf:
	Like scanf, except that the first argument is
	a pointer to a buffered input file buffer, and
	the text is taken from the file instead of from
	the console.
	Usage:
		fscanf(iobuf, format, ptr1, ptr2, ...);
	Returns number of items matched (zero on EOF.)
	Note that any unprocessed text is lost forever. Each
	time scanf is called, a new line of input is gotten
	from the file, and any information left over from
	the last call is wiped out. Thus, the text in the
	file must be arranged such that a single call to
	fscanf will always get all the required data on a
	line. This is not compatible with the way UNIX does
	things, but it eliminates the need for separate
	scanning functions for files, strings, and console
	input; it is more economical to let both "fscanf" and
	"scanf" use "sscanf". If you want to be able to scan
	a partial line with fscanf and have the rest still be
	there on the next fscanf call, you'll have to rewrite
	fscanf to be self contained (not use sscanf) and use
	"ungetc" to push back characters.

	Returns number of items succesfully matched.
*/

extern char *_scanend,_scan_line[MAXLINE];
extern int _oldfile;
char *fgets();

int fscanf(file,format)
int  *file;
char *format;
{
	static char *fscanf_from;
	int numin;

	_scanend=fscanf_from;
	if (fscanf_from == 0 || _oldfile != (int)file) {
		if (!fgets(_scan_line,MAXLINE,file)) return -1;
		_scanend=_scan_line;
		}
	numin= _scn(&format);	/* and scan it with "_scn"	 */
	fscanf_from=0;
	if (_igs()) fscanf_from=_scanend;
	_oldfile=(long)file;
	return numin;
}

/*
 * frexp returns the mantissa of a double "value" as a double
 * quantity, "x", of magnitude less than 1.0 and stores an integer
 * "n" (such that "value" = "x" * 2 ** "n") indirectly through "eptr"
 */

double frexp(value, eptr)
double value;
int *eptr;
	{
	int *ip;

	if(value == 0.0)
		*eptr = 0;
	else
		{
		ip = &value;
		*eptr = ((ip[3] >> 4) & 0x7FF) - 0x3FE;
		ip[3] = (ip[3] & 0x800F) + 0x3FE0;
		}
	return value;
	}

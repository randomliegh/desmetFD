/*	STRSET  --	set the characters of a string */

char *strset(str,ch)
	char *str;
	char ch; {
	int i;

	i=0;
	i=strlen(str)-1;
	while (i >= 0) {
		str[i--]=ch;
		}
	return str;
	}

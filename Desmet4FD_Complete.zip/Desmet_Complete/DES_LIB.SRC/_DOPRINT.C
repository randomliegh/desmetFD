#define MAXLINE 258	/* Longest line of input expected from the console */
char toupper(), isdigit();

/*
	General formatted output conversion routine, used by
	fprintf and sprintf..."line" is where the output is
	written, and "fmt" is a pointer to an argument list 
	which must consist of a format string pointer and
	subsequent list of (optional) values. Having arguments
	passed on the stack works out a heck of a lot neater
	than it did before when the args were passed via an
	absolute vector in low memory!
*/

/*
	Internal routine used by "_spr" to perform ascii-
	to-decimal conversion and update an associated pointer:
*/

static int _gv2(sptr)
char **sptr;
{
	int n;
	n = 0;
	while (isdigit(**sptr)) n = 10 * n + *(*sptr)++ - '0';
	return n;
}

static _tohex(char ** ptr, unsigned val) {
	int v;

	v = (val >> 12) & 15;
	*(*ptr)++ = (v < 10) ? v + '0' : v + 55 ;
	v = (val >> 8) & 15;
	*(*ptr)++ = (v < 10) ? v + '0' : v + 55 ;
	v = (val >> 4) & 15;
	*(*ptr)++ = (v < 10) ? v + '0' : v + 55 ;
	v = val & 15;
	*(*ptr)++ = (v < 10) ? v + '0' : v + 55 ;
	}

/*
	Internal function which converts n into an ASCII
	base `base' representation and places the text
	at the location pointed to by the pointer pointed
	to by `string'. Yes, you read that correctly.
*/

static char _uspr(string, n, base, c)
char **string, c;
unsigned n;
{
	char length;
	if (n<base) {
		*(*string)++ = (n < 10) ? n + '0' : n + ((c == 'X') ? 55 : 87);
		return 1;
	}
	length = _uspr(string, n/base, base, c);
	_uspr(string, n%base, base, c);
	return length + 1;
}

/*
	Same as above except for longs.	*/

static char _duspr(string, n, base, c)
char **string, c;
long n;
int  base;
{
	char length;
	if (n >= 0 && n < base) {
		*(*string)++ = (n < 10) ? n + '0' : n + ((c == 'X') ? 55 : 87);
		return 1;
		}
	if (base == 8) {
		length = _duspr(string, n>>3, base, c);
		_duspr(string, n & 7, base, c);
		}
	else if (base == 16) {
		length = _duspr(string, n>>4, base,c);
		_duspr(string, n & 15, base,c);
		}
	else {
		if (n < 0) {
			length='0';
			while (n < 0 || n > 1000000000) {
				n-=1000000000;
				length++;
				}
			*(*string)++=length;
			return _duspr(string,n,base,c)+1;
			}
		length = _duspr(string, n/base, base,c);
		_duspr(string, n%base, base,c);
		}
	return length + 1;
	}

union {long dword; char bytes[8];};

_doprint(int (* put)(), char * f, char ** fmt) {
	char c, base, *sptr, *format;
	char wbuf[MAXLINE], *wptr, df, lf, pf, ljflag, zfflag, plusf, blankf, sharpf;
	int width, precision,  *args, siz, nchars = 0;

	format = *fmt++;    /* fmt first points to the format string	*/
	args = fmt;	    /* now fmt points to the first arg value	*/

	while (c = *format++)
	  if (c == '%') {
	    wptr = wbuf;
	    ljflag = df = lf = pf = zfflag = plusf = blankf = sharpf = 0;
   		precision = 6;

		while(1) {
			switch(c = *format) {
				case '-':	ljflag++;
							format++;
							continue;
		    	case '+':	plusf++;
							format++;
		    				continue;
		    	case ' ':	blankf++;
							format++;
		    				continue;
				case '#':	sharpf++;
							format++;
							continue;
				case '0':	zfflag++;
							format++;
							continue;
				}
			break;
		    }

	    if(isdigit(c))
	    	width = _gv2(&format);
	    else if(c == '*') {
	    	width = *args++;
	    	if(width < 0) {
	    		ljflag++;
	    		width = -width;
	    		}
	    	format++;
	    	}
	    else
	    	width = 0;

	    if ((c = *format++) == '.') {
	    	df++;
		    if(isdigit(c = *format))
		    	precision = _gv2(&format);
	    	else if(c == '*') {
		    	if((precision = *args++) < 0)
		    		precision = -precision;
		    	format++;
		    	}
		    pf++;
		    if(precision > MAXLINE - 1)
		    	precision = MAXLINE - 1;
			c=*format++;
			}

		if (c == 'l' || c == 'L') {
			lf++;
		    c=*format++;
	     	}

	    switch(c) {

		case 'i':
		case 'd':	if (!lf && *args < 0) {
						*wptr++ = '-';
						*args = -*args;
						width--;
			    		}
					else if (lf && ((void*)args)->dword < 0) {
						*wptr++ = '-';
						((void*)args)->dword = -((void*)args)->dword;
						width--;
			    		}
			    	else if(blankf) {
			    		*wptr++ = ' ';
			    		width--;
			    		}
			    	else if(plusf) {
			    		*wptr++ = '+';
			    		width--;
			    		}

		case 'u':	base = 10; goto val;

		case 'x':
		case 'X':	base = 16;
					if(sharpf) {
						*wptr++ = '0';
						*wptr++ = c;
						width -= 2;
						}
					goto val;

		case 'o':	base = 8;  /* note that arbitrary bases can be
				         added easily before this line */
					if(sharpf) {
						*wptr++ = '0';
						width--;
						}
		     val:	if(df)
		     			zfflag++;
		     		if(lf) {
						width -= _duspr(&wptr,((void*)args)->dword,base,c);
						args+=2;
						}
		     		else 
			     	   width -= _uspr(&wptr,*args++,base,c);
				  	goto pad;

		case 'n':	**(int **)args++=nchars;
					continue;

		case 'p':	width=0;

#ifdef LARGE_CASE
					_tohex(&wptr,*(args+1));
					*wptr++=':';
					_tohex(&wptr,*args++);
					args++;
# else
					_tohex(&wptr,*args++);
#endif
					goto pad;

		case 'e':
		case 'E':
		case 'f':
		case 'F':
		case 'g':
		case 'G':	if (((void*)args)->bytes[7] & 0x80) {
						*wptr++='-';
						((void*)args)->bytes[7]&=0x7f;
						width--;
						}
			    	else if(blankf) {
			    		*wptr++ = ' ';
			    		width--;
			    		}
			    	else if(plusf) {
			    		*wptr++ = '+';
			    		width--;
			    		}
					c=toupper(c);
					if (c == 'E')
						siz = _efmt(wptr,args,precision);
					else if (c == 'F')
						siz = _ffmt(wptr,args,precision);
					else
						siz = _gfmt(wptr,args,precision);
					if(sharpf && precision == 0)
						wptr[siz++] = '.';
					width-=siz;
					wptr[siz]=0;
					args+=4;
					goto pad2;

		case 'c':  *wptr++ = *args++;
				   width--;
				   goto pad;

		case 's':  	if (!pf)
						precision = MAXLINE - 1;
			   		sptr = *((char **)args)++;
			   		while (*sptr && precision) {
						*wptr++ = *sptr++;
						precision--;
						width--;
			    		}

		     pad:  *wptr = '\0';
		     pad2:	wptr = wbuf;
				   if (!ljflag) {
				   		if( zfflag 
				   			&& (*wptr == '+' || *wptr == '-' || *wptr == ' ')) {
				   				nchars++;
				   				if((*put)(*wptr++, f) == -1)
				   					return -1;
				   				}
						while (width-- > 0) {
			   				nchars++;
			   				if((*put)(zfflag ? '0' : ' ', f) == -1)
			   					return -1;
							}
						}

				   while (*wptr) {
		   				nchars++;
		   				if((*put)(*wptr++, f) == -1)
		   					return -1;
		   				}

				   if (ljflag)
					while (width-- > 0) {
		   				nchars++;
		   				if((*put)(' ', f) == -1)
		   					return -1;
		   				}
				   break;

		 default:  nchars++;
		   		   if((*put)(c, f) == -1)
		   		   	return -1;
	     }
	  }
	  else { nchars++; if((*put)(c, f) == -1) return -1; }
	return nchars;
}

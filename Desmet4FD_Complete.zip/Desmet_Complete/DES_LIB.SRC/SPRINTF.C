/*
	sprintf:
	Like fprintf, except a string pointer is specified
	instead of a buffer pointer. The text is written
	directly into memory where the string pointer points.

	Usage:
		sprintf(string,format,arg1, arg2, ...);
*/

static sputc(char ch, char **ptr) { return *(*ptr)++ = ch; }

sprintf(char * buf, char * fmt) { 
	int n;

	n = _doprint(sputc, &buf, &fmt);
	*buf = 0;
	return n;
	}
